import LoadingAnimation from "@/components/loading-animation"

export default function Loading() {
  return <LoadingAnimation />
}
